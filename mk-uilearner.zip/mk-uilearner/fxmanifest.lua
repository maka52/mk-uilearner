fx_version 'cerulean'
game 'gta5'
author 'MK-Scripts (Maka)'
title 'UI Learner'
description 'Use this to learn how to work with UI'

client_script 'main.lua'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/listener.js'
}