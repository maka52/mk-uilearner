Just used this YT video but it saves time

https://www.youtube.com/watch?v=WxMOk-FuG2U&list=PLIpzpS7fwntTQOAh2bS8Tz-g8NP4WFhG2&ab_channel=Jeva

The command to get rid of the UI is 'off' and is 'on' to get it back (may need to use this if you are making something move e.g a progress bar)